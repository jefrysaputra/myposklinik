-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               10.4.14-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for klinikhewan
CREATE DATABASE IF NOT EXISTS `klinikhewan` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `klinikhewan`;

-- Dumping structure for table klinikhewan.datahewans
DROP TABLE IF EXISTS `datahewans`;
CREATE TABLE IF NOT EXISTS `datahewans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idowner` int(11) NOT NULL DEFAULT 0,
  `namahewan` varchar(200) NOT NULL DEFAULT '0',
  `idrashewan` varchar(50) NOT NULL DEFAULT '0',
  `idjenishewan` varchar(50) NOT NULL DEFAULT '0',
  `jeniskelaminhewan` varchar(2) NOT NULL DEFAULT '0',
  `tahunlahirhewan` varchar(5) NOT NULL DEFAULT '0',
  `namafotohewan` varchar(50) NOT NULL DEFAULT '0',
  `flag` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.datahewans: ~0 rows (approximately)
DELETE FROM `datahewans`;
/*!40000 ALTER TABLE `datahewans` DISABLE KEYS */;
/*!40000 ALTER TABLE `datahewans` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.datakaryawans
DROP TABLE IF EXISTS `datakaryawans`;
CREATE TABLE IF NOT EXISTS `datakaryawans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namakaryawan` varchar(200) NOT NULL DEFAULT '0',
  `nikkaryawan` varchar(30) NOT NULL DEFAULT '0',
  `jeniskelaminkaryawan` varchar(2) NOT NULL DEFAULT '0',
  `tanggallahirkaryawan` date NOT NULL,
  `alamatkaryawan` varchar(300) NOT NULL DEFAULT '0',
  `nohpkaryawan` varchar(30) NOT NULL DEFAULT '0',
  `emailkaryawan` varchar(30) NOT NULL DEFAULT '0',
  `sosmedkaryawan` varchar(30) NOT NULL DEFAULT '0',
  `idjabatankaryawan` int(11) NOT NULL DEFAULT 0,
  `namfotoktp` varchar(30) NOT NULL DEFAULT '0',
  `flag` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.datakaryawans: ~3 rows (approximately)
DELETE FROM `datakaryawans`;
/*!40000 ALTER TABLE `datakaryawans` DISABLE KEYS */;
INSERT INTO `datakaryawans` (`id`, `namakaryawan`, `nikkaryawan`, `jeniskelaminkaryawan`, `tanggallahirkaryawan`, `alamatkaryawan`, `nohpkaryawan`, `emailkaryawan`, `sosmedkaryawan`, `idjabatankaryawan`, `namfotoktp`, `flag`) VALUES
	(3, 'test nama1', '0', 'P', '2020-04-06', 'tesalamat 1', 'nohp1', 'email 1', 'socmed 1', 2, '0', '0'),
	(4, 'testnama2e', 'nik2e', 'P', '1990-01-02', 'alamat2e', 'nohp2e', 'email2e', 'dsadsad', 1, '0', '0');
/*!40000 ALTER TABLE `datakaryawans` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.dataowners
DROP TABLE IF EXISTS `dataowners`;
CREATE TABLE IF NOT EXISTS `dataowners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namalengkap` varchar(255) NOT NULL DEFAULT '0',
  `nik` varchar(30) NOT NULL DEFAULT '0',
  `tgllahir` date NOT NULL,
  `jeniskelamin` varchar(2) NOT NULL DEFAULT '0',
  `alamat` varchar(255) NOT NULL DEFAULT '0',
  `nohp` varchar(39) NOT NULL DEFAULT '0',
  `email` varchar(100) NOT NULL DEFAULT '0',
  `sosmedid` varchar(2) NOT NULL DEFAULT '0',
  `flag` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.dataowners: ~0 rows (approximately)
DELETE FROM `dataowners`;
/*!40000 ALTER TABLE `dataowners` DISABLE KEYS */;
/*!40000 ALTER TABLE `dataowners` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.laporanpoints
DROP TABLE IF EXISTS `laporanpoints`;
CREATE TABLE IF NOT EXISTS `laporanpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerid` varchar(50) NOT NULL DEFAULT '0',
  `ownernik` varchar(30) NOT NULL DEFAULT '0',
  `ownertgllahir` date NOT NULL,
  `ownerjeniskelamin` varchar(2) NOT NULL DEFAULT '0',
  `owneralamat` varchar(300) NOT NULL DEFAULT '0',
  `ownernohp` varchar(30) NOT NULL DEFAULT '0',
  `owneremail` varchar(30) NOT NULL DEFAULT '0',
  `owneridsosmed` varchar(2) NOT NULL DEFAULT '0',
  `hewanid` int(11) NOT NULL DEFAULT 0,
  `hewannama` varchar(200) NOT NULL DEFAULT '0',
  `hewanjenisid` int(11) NOT NULL DEFAULT 0,
  `hewanrasid` int(11) NOT NULL DEFAULT 0,
  `hewanjeniskelamin` varchar(2) NOT NULL DEFAULT '0',
  `hewantahunlahir` varchar(5) NOT NULL DEFAULT '0',
  `point` int(11) NOT NULL DEFAULT 0,
  `tanggalupdate` date NOT NULL DEFAULT current_timestamp(),
  `idlogin` varchar(50) NOT NULL,
  `flag` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.laporanpoints: ~0 rows (approximately)
DELETE FROM `laporanpoints`;
/*!40000 ALTER TABLE `laporanpoints` DISABLE KEYS */;
/*!40000 ALTER TABLE `laporanpoints` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.masterhewans
DROP TABLE IF EXISTS `masterhewans`;
CREATE TABLE IF NOT EXISTS `masterhewans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namahewan` varchar(200) DEFAULT '0',
  `flag` varchar(2) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.masterhewans: ~3 rows (approximately)
DELETE FROM `masterhewans`;
/*!40000 ALTER TABLE `masterhewans` DISABLE KEYS */;
INSERT INTO `masterhewans` (`id`, `namahewan`, `flag`) VALUES
	(1, 'ABJH', '1'),
	(3, 'test', '0'),
	(4, 'ds', '0');
/*!40000 ALTER TABLE `masterhewans` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.masterjabatans
DROP TABLE IF EXISTS `masterjabatans`;
CREATE TABLE IF NOT EXISTS `masterjabatans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namajabatan` varchar(100) NOT NULL DEFAULT '0',
  `flag` varchar(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.masterjabatans: ~3 rows (approximately)
DELETE FROM `masterjabatans`;
/*!40000 ALTER TABLE `masterjabatans` DISABLE KEYS */;
INSERT INTO `masterjabatans` (`id`, `namajabatan`, `flag`) VALUES
	(1, 'test', '1'),
	(2, 'jabatan1', '2'),
	(3, 'jabatan2', '0'),
	(6, 'asad', '0');
/*!40000 ALTER TABLE `masterjabatans` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.masterrashewans
DROP TABLE IF EXISTS `masterrashewans`;
CREATE TABLE IF NOT EXISTS `masterrashewans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namarashewan` varchar(200) NOT NULL DEFAULT '0',
  `flag` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.masterrashewans: ~1 rows (approximately)
DELETE FROM `masterrashewans`;
/*!40000 ALTER TABLE `masterrashewans` DISABLE KEYS */;
INSERT INTO `masterrashewans` (`id`, `namarashewan`, `flag`) VALUES
	(1, 'pitbull oy', '0'),
	(3, 'bulldog', '0');
/*!40000 ALTER TABLE `masterrashewans` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.mastersosmeds
DROP TABLE IF EXISTS `mastersosmeds`;
CREATE TABLE IF NOT EXISTS `mastersosmeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namasosmed` varchar(200) NOT NULL DEFAULT '0',
  `flag` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.mastersosmeds: ~0 rows (approximately)
DELETE FROM `mastersosmeds`;
/*!40000 ALTER TABLE `mastersosmeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `mastersosmeds` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.mastertypes
DROP TABLE IF EXISTS `mastertypes`;
CREATE TABLE IF NOT EXISTS `mastertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `namatype` varchar(200) DEFAULT '0',
  `flag` varchar(5) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.mastertypes: ~0 rows (approximately)
DELETE FROM `mastertypes`;
/*!40000 ALTER TABLE `mastertypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `mastertypes` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.masterusers
DROP TABLE IF EXISTS `masterusers`;
CREATE TABLE IF NOT EXISTS `masterusers` (
  `id` int(11) NOT NULL,
  `karyawanid` varchar(50) NOT NULL,
  `jabatanid` varchar(50) NOT NULL,
  `typeuserid` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tanggalupdate` datetime NOT NULL,
  `flag` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.masterusers: ~0 rows (approximately)
DELETE FROM `masterusers`;
/*!40000 ALTER TABLE `masterusers` DISABLE KEYS */;
/*!40000 ALTER TABLE `masterusers` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table klinikhewan.migrations: ~0 rows (approximately)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(4, '2019_02_15_094029_create_shares_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.shares
DROP TABLE IF EXISTS `shares`;
CREATE TABLE IF NOT EXISTS `shares` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `share_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `share_price` int(11) NOT NULL,
  `share_qty` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table klinikhewan.shares: ~2 rows (approximately)
DELETE FROM `shares`;
/*!40000 ALTER TABLE `shares` DISABLE KEYS */;
INSERT INTO `shares` (`id`, `share_name`, `share_price`, `share_qty`, `created_at`, `updated_at`) VALUES
	(1, 'Item 2', 5000, 250, '2019-02-15 10:40:25', '2020-04-21 12:21:56'),
	(4, 'Item 1', 3500, 100, '2019-02-15 14:59:06', '2020-04-21 12:21:42');
/*!40000 ALTER TABLE `shares` ENABLE KEYS */;

-- Dumping structure for table klinikhewan.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `level` int(2) DEFAULT NULL,
  `flag` varchar(5) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table klinikhewan.users: ~2 rows (approximately)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `username`, `password`, `name`, `address`, `level`, `flag`) VALUES
	(2, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'robby', 'delta asri 2', 1, '0'),
	(3, 'kasir', '8691e4fc53b99da544ce86e22acba62d13352eff', 'wiwin', 'kudus', 2, '0');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
